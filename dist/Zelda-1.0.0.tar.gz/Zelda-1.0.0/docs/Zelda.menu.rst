Zelda.menu
==================

Zelda.menu.DeathScreen
-----------------------------

.. automodule:: Zelda.menu.DeathScreen
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.menu.EscMenu
-------------------------

.. automodule:: Zelda.menu.EscMenu
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.menu.StartMenu
---------------------------

.. automodule:: Zelda.menu.StartMenu
   :members:
   :undoc-members:
   :show-inheritance:

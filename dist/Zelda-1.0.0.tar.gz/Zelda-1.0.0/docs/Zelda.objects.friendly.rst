Zelda.objects.friendly
==============================

Zelda.objects.friendly.Player
------------------------------------

.. automodule:: Zelda.objects.friendly.Player
   :members:
   :undoc-members:
   :show-inheritance:

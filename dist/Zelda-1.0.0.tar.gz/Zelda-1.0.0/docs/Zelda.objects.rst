Zelda.objects
=====================

.. toctree::
   :maxdepth: 4

   Zelda.objects.enemy
   Zelda.objects.friendly
   Zelda.objects.main
   Zelda.objects.weapon

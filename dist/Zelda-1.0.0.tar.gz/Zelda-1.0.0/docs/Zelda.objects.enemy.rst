Zelda.objects.enemy
===========================

Zelda.objects.enemy.Enemy
--------------------------------

.. automodule:: Zelda.objects.enemy.Enemy
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.enemy.Ninja
--------------------------------

.. automodule:: Zelda.objects.enemy.Ninja
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.enemy.Skeleton
-----------------------------------

.. automodule:: Zelda.objects.enemy.Skeleton
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.enemy.StrongSwordsman
------------------------------------------

.. automodule:: Zelda.objects.enemy.StrongSwordsman
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.enemy.Swordsman
------------------------------------

.. automodule:: Zelda.objects.enemy.Swordsman
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.enemy.Turret
---------------------------------

.. automodule:: Zelda.objects.enemy.Turret
   :members:
   :undoc-members:
   :show-inheritance:
   
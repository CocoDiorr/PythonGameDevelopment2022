Zelda.objects.weapon
============================

Zelda.objects.weapon.Bow
-------------------------------

.. automodule:: Zelda.objects.weapon.Bow
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.Bullet
----------------------------------

.. automodule:: Zelda.objects.weapon.Bullet
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.ColdSteel
-------------------------------------

.. automodule:: Zelda.objects.weapon.ColdSteel
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.Shield
----------------------------------

.. automodule:: Zelda.objects.weapon.Shield
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.ShootingWeapon
------------------------------------------

.. automodule:: Zelda.objects.weapon.ShootingWeapon
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.Shuriken
------------------------------------

.. automodule:: Zelda.objects.weapon.Shuriken
   :members:
   :undoc-members:
   :show-inheritance:

Zelda.objects.weapon.Weapon
----------------------------------

.. automodule:: Zelda.objects.weapon.Weapon
   :members:
   :undoc-members:
   :show-inheritance:


<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetReliefDetail" tilewidth="16" tileheight="16" tilecount="108" columns="12">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetReliefDetail.png" width="192" height="144"/>
</tileset>

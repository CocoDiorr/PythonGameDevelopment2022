<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="borderblock" tilewidth="1" tileheight="1" tilecount="0" columns="0"/>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Walk" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Actor/Characters/BlueSamurai/SeparateAnim/Walk.png" width="64" height="64"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetHouse" tilewidth="32" tileheight="32" tilecount="154" columns="14">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetHouse.png" width="464" height="368"/>
</tileset>

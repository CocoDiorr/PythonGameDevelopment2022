<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetNature" tilewidth="16" tileheight="16" tilecount="288" columns="16">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetNature.png" width="256" height="288"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetFloor" tilewidth="16" tileheight="16" tilecount="572" columns="22">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetFloor.png" width="352" height="417"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetNature" tilewidth="32" tileheight="32" tilecount="72" columns="8">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetNature.png" width="256" height="288"/>
</tileset>

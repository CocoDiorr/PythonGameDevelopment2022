<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="TilesetWater" tilewidth="16" tileheight="16" tilecount="476" columns="28">
 <image source="../../../../NinjaAdventure/NinjaAdventure/Backgrounds/Tilesets/TilesetWater.png" width="448" height="272"/>
</tileset>

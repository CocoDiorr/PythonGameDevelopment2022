"""This module is used to operate with weapons."""

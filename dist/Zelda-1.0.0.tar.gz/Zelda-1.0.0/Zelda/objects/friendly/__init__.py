"""This module is used to operate with Player."""

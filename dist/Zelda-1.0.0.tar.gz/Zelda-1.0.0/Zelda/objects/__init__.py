"""This module is used to operate with objects on the map."""

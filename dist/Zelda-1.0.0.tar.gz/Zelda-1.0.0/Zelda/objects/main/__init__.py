"""This module is used to operate with main base object's classes."""

"""This module is used to operate with settings and animations."""

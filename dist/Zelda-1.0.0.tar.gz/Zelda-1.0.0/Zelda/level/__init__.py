"""This module is used to draw the map and movements."""

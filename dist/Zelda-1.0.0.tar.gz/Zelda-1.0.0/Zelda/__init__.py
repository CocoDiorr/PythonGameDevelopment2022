"""Zelda module init."""
